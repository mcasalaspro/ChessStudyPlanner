# Chess Study Planner — guia particular (não vai para o GitHub)

Este arquivo, o `publicar.bat` e a pasta `supabase/` estão no `.gitignore`: ficam no seu computador
e **não** são enviados para o repositório. O que fica público é só o site em si.

---

## 1. Banco de dados (uma vez só)

1. Crie um projeto grátis em <https://supabase.com> → **New project** (região South America / São Paulo).
2. **SQL Editor → New query** → cole todo o conteúdo de `supabase/schema.sql` → **Run**.
   Isso cria a tabela `study_records` e as políticas de segurança (RLS) que limitam cada pessoa às próprias linhas.
3. **Authentication → Sign In / Providers**:
   - provedor **Email** ligado e **Confirm email desligado** (assim quem você criar entra na hora);
   - **Allow new users to sign up desligado** — ninguém se cadastra sozinho, só você cria contas.
4. **Project Settings → API Keys**: copie a **Project URL** e a **publishable key** (`sb_publishable_…`).
   Nunca use as chaves marcadas *SECRET* aqui: elas ignoram as regras de segurança.
5. Abra `config.js` e preencha **dentro das aspas** (o que está depois de `//` é só comentário e não vale nada):

```js
window.CSP_CONFIG = {
  supabaseUrl: 'https://uytbslmuiauougzctrdk.supabase.co',   // sem /rest/v1 no fim
  supabaseAnonKey: 'sb_publishable_...',
  homeUrl: '',   // opcional: link do botão "Back" no topo
};
```

O `config.js` **não vem nos pacotes de atualização** — só o `config.example.js`. Assim, quando você
jogar arquivos novos na pasta, o seu continua intacto.

## 2. Criar usuários

**Authentication → Users → Add user → Create new user**: e-mail, senha e **Auto Confirm User** marcado.
Repita para cada pessoa. Trocar senha ou remover alguém: menu `⋯` ao lado do usuário.
Sem conta ninguém passa da tela de login, e cada login só enxerga os próprios blocos.

## 3. Publicar / atualizar

Repositório já configurado no `publicar.bat`: <https://github.com/mcasalaspro/ChessStudyPlanner.git>

1. Dois cliques em **`publicar.bat`**. Na primeira vez ele pede só nome e e-mail para os commits.
   Se o Git pedir senha, use um Personal Access Token (GitHub → Settings → Developer settings → Tokens).
   Antes de enviar ele avisa se o `config.js` estiver vazio.
2. Só na primeira vez: **Settings → Pages → Deploy from a branch → main / (root) → Save**.
3. O site fica em <https://mcasalaspro.github.io/ChessStudyPlanner/> (1–2 min por atualização).
4. Toda mudança futura: dois cliques no `.bat` de novo.

## 4. Imagens de fundo e frases

- **Fundo:** a pasta `assets/bg/` guarda as imagens. Jogue quantas quiser lá, nomeadas `1`, `2`, `3`…
  com extensão `.webp`, `.jpg`, `.jpeg` ou `.png`. Todo dia o app sorteia uma (a mesma o dia inteiro).
  Em ⚙ Settings → *Background picture* você escolhe o quanto ela aparece (**Discreet / Medium / Strong**,
  padrão Strong) e usa **🖼 Next picture** para pular para a próxima imagem da pasta — útil para testar.
  A escolha vale até o dia seguinte; *Day's pick* volta ao sorteio. Imagens menores que a tela são
  suavizadas automaticamente para não ficarem quadriculadas — o ideal são fotos de 1920 px de largura ou mais.
- **Frases:** ficam em `js/13-quotes.js` (196 frases, incluindo enxadristas). A frase do dia fica sempre
  visível na faixa do topo (a mesma o dia inteiro; clique nela para ver outra) e acompanha o modo foco. Para acrescentar, copie uma linha do arquivo:
  `{ t: "texto da frase", s: "autor" },`

## 5. Uso do app (para você repassar a quem quiser)

- **Today** — faixa no topo com o dia inteiro (0–24 h) em tamanho grande, os blocos de hoje e uma
  barra branca marcando a hora atual. Dá para arrastar e ajustar os blocos ali mesmo, e os botões
  **+30 min / +1 h / +2 h** criam um bloco começando agora.
- **Study timer** — escolha o tema, **Start**. *+10 min* recua o início quando você esqueceu de ligar o cronômetro.
  Os botões **30 min / 1 h / 2 h**: com o cronômetro parado, lançam um bloco já pronto terminando agora;
  com ele rodando, viram uma meta e o bloco se encerra sozinho ao atingir esse tempo líquido.
  *Break reminder every (min)* avisa a cada N minutos de estudo.
- **Log hours manually** — tema, data, hora, duração (também com os três botões) e comentário → **Log**.
- **Missions** — botão **+ New mission** abre uma janelinha para criar (nome, tema, meta, início e prazo),
  deixando a tela limpa. Cada missão vira um **card retangular** com medalha: apagada enquanto está em
  andamento, dourada quando a meta é batida. Só contam as horas daquele tema dentro da janela de datas.
- **Study calendar** — clique num bloco para editar no painel lateral (tema, data, início, fim, duração,
  pausas, comentário, e os botões de duração); arraste para mover, puxe as bordas para redimensionar,
  Alt+arrastar duplica, clique num espaço vazio para criar. Blocos com comentário mostram o ícone 💬.
  Teclado: ←→ move 15 min, Shift+←→ muda o fim, ↑↓ muda o dia, Enter abre, Del apaga, Ctrl+Z desfaz.
- **Reports** e **📄 Study report** (Save PDF usa a impressão do navegador).
- **Modo foco** — animação suave de fundo, a frase do dia e uma barra grande com o planejamento:
  trechos brancos = estudo, azuis = pausa, marcador amarelo no momento atual. Com meta definida a barra
  segue a meta; sem meta, mostra duas rodadas (estudo–pausa–estudo–pausa). O botão **Stop** sai do foco
  antes de pedir confirmação. A duração da pausa (10, 15 ou 30 min) fica ao lado do cronômetro e em ⚙.
- **Horário de dormir** — em ⚙ Settings → *Freeze night hours*: escolha de que hora a que hora você dorme
  (padrão 23:00–07:00). Essas horas ficam hachuradas na linha do tempo e não aceitam blocos novos, então
  não dá para planejar estudo em cima do sono por engano. Desligue o congelamento quando quiser usá-las.
- **Pausa guiada** (ligada por padrão, em ⚙ Settings): ao completar o tempo de estudo definido, o
  cronômetro pausa sozinho e mostra a contagem regressiva da pausa em azul; quando ela acaba, ele volta
  a contar sozinho, com aviso sonoro. Dá para pular (**Skip break**) ou esticar (**+5 min break**).
- **Como foi a sessão** — ao encerrar um bloco, três botões no painel (*Focused / Normal / Scattered*).
  A avaliação alimenta a seção **Focus quality** do relatório: proporção de cada nível, o horário em que
  você rende mais e a média por tema.
- **Conquistas** — 12 medalhas no relatório (primeiro bloco, semana cheia, 10 e 30 dias seguidos, 10/100/500
  horas, madrugador, 50 blocos, missão concluída, 5 temas, 20 blocos concentrados), com barra de progresso
  nas que ainda faltam.
- **⚙ Settings** — nome no relatório, temas (nome/cor/adicionar/remover), duração da pausa, tempos do cronômetro, som,
  notificações, exportar CSV/JSON, importar backup, dados de exemplo, apagar tudo e sair da conta.
- Atalhos: Espaço pausa/retoma · F modo foco · N nota rápida · Ctrl+Z desfaz.

## 6. Dados

Grava primeiro no navegador e envia para o banco em seguida (indicador *Synced / Saving / Offline* no topo).
Sem internet o trabalho continua e sobe quando a conexão volta; a cada 5 min o app puxa o que mudou,
então dá para usar em vários aparelhos com a mesma conta. Não existe mais modo local: sem login, sem app.
De vez em quando faça **⚙ → JSON backup**. O plano grátis do Supabase pausa projetos sem uso por ~7 dias;
basta reativar no painel, nada se perde.
